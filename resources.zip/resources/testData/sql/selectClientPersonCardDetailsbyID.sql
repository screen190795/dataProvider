select
c.card_id as client_id,
cp.card_id as "personCard_id"
from commons.client c join commons.personcard cp on c.card_id = cp.client_id
where c.card_id =:card_id
