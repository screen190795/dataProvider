select card_id,
name
from commons.branch