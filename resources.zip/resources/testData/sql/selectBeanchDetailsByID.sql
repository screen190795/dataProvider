select card_id,
name
from commons.branch
where card_id =:card_id