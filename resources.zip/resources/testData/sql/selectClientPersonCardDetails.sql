select
c.card_id as client_id,
c.surname,
c.firstname,
c.secondname,
c.birth,
c.state,
c.email,
c.phone,
c.gender,
cp.address,
cp.card_id as "personCard_id",
cp.series,
cp.no,
cp.type,
cp.expiry,
cp.state
 from commons.client c join commons.personcard cp on c.card_id = cp.client_id
where c.state = 1
and c.secondname is not null
